/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package proyecto2.modelado;

import javax.swing.ImageIcon;
import javax.swing.JLabel;

/**
 *
 * @author Poncho Mondragon
 */
public class Main{

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args){
        Menu menu = new Menu();
        menu.setVisible(true);
        menu.setLocationRelativeTo(null);
        
    }
    
}
